/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GAFunctions;

/**
 *
 * @author LMH
 */
public class SelectPopulation {
	Tour[] selectTours;
	private int N;
	
	public SelectPopulation(int num) {
		selectTours = new Tour[num + 1];
	}
	
	public boolean isEmpty() {
		return N == 0;
	}
	
	public void insert(Tour tour) {
		selectTours[++ N] = tour;
		swim(N);
	}
	
	public Tour delMin() {
		Tour min = selectTours[1];
		exch(1, N --);
		sink(1);
		selectTours[N + 1] = null;
		return min;
	}
	
	private void sink(int k) {
		while (2*k <= N) {
			int j = 2*k;
			if(j < N && large(j, j + 1)) {
				j++;
			}
			
			if(large(j, k)) {
				break;
			}
			
			exch(k, j);
			k = j;
		}
	}
	
	private void swim(int k) {
		while (k > 1 && large(k/2, k)) {
			exch(k, k/2);
			k = k/2;
		}
	}
	
	private boolean large(int x, int y) {
		return selectTours[x].fitness > selectTours[y].fitness;
	}
	
	private void exch(int x, int y) {
		Tour temp = selectTours[x];
		selectTours[x] = selectTours[y];
		selectTours[y] = temp;
	}
	
	public Tour getFittestTour() {
		Tour fittestTour = selectTours[0];
		for(int i = 0; i < selectTours.length; i ++) {
			if(selectTours[i].fitness > fittestTour.fitness) {
				fittestTour = selectTours[i];
			}
		}
		return fittestTour;
	}
	
}
