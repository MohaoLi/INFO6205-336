/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GAFunctions;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.data.category.DefaultCategoryDataset;

public class DriverGA {

    public static void main(String[] args) {
        // Data
        ArrayList<City> cityList = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < 2000; i++) {
            int x = random.nextInt(1000);
            int y = random.nextInt(1000);
            City city = new City(x, y);
            City departure = new City(90, 150);
            City destination = new City(20, 150);
            while (city.equals(departure) || city.equals(destination)) {
                x = random.nextInt(300);
                y = random.nextInt(300);
                city = new City(x, y);
            }
            cityList.add(city);
        }
//        City city = new City(60, 200);
//        cityList.add(city);
//        City city2 = new City(180, 200);
//        cityList.add(city2);
//        City city3 = new City(80, 180);
//        cityList.add(city3);
//        City city4 = new City(140, 180);
//        cityList.add(city4);
//        City city5 = new City(20, 160);
//        cityList.add(city5);
//        City city6 = new City(100, 160);
//        cityList.add(city6);
//        City city7 = new City(200, 160);
//        cityList.add(city7);
//        City city8 = new City(140, 140);
//        cityList.add(city8);
//        City city9 = new City(40, 120);
//        cityList.add(city9);
//        City city10 = new City(100, 120);
//        cityList.add(city10);
//        City city11 = new City(70, 200);
//        cityList.add(city11);
//        City city12 = new City(170, 200);
//        cityList.add(city12);
//        City city13 = new City(50, 180);
//        cityList.add(city13);
//        City city14 = new City(130, 170);
//        cityList.add(city14);
//        City city15 = new City(30, 230);
//        cityList.add(city15);
//        City city16 = new City(110, 165);
//        cityList.add(city16);
//        City city17 = new City(190, 160);
//        cityList.add(city17);
//        City city18 = new City(160, 130);
//        cityList.add(city18);
//        City city19 = new City(90, 70);
//        cityList.add(city19);
//        City city20 = new City(170, 190);
//        cityList.add(city20);

        DriverGA driverGA = new DriverGA();
        driverGA.begin(1000, 500, 1, 0.5, cityList);

    }

    public void begin(int size, int filterSize, double crossoverRate, double mutateRate, ArrayList<City> cityList) {
        Population population = new Population();
        DefaultCategoryDataset lineChartData = new DefaultCategoryDataset();
        ChartPanel chartPanel =new ChartPanel(null);
        JFreeChart chart = ChartFactory.createLineChart("Fitness", "10 second per column", "Generation", lineChartData);
        chart.setBackgroundPaint(Color.BLUE);
        chart.getTitle().setPaint(Color.RED);
        CategoryPlot p = chart.getCategoryPlot();
        p.setRangeGridlinePaint(Color.YELLOW);
        ChartFrame frame = new ChartFrame("Line Chart Of Fitness", chart);
        frame.setVisible(true);
        frame.setSize(450,350);
        int generation = 0;
        for (int i = 0; i < size; i++) {
            Tour tour = new Tour(cityList);
            population.tours.add(tour);
        }
        //population.tours.forEach(a -> System.out.println("fitness"+""+a.fitness));
        population.selectPopulation();
//		population.getFittestTour();
        System.out.println(
                "the generation:" + generation + " " + "distance:" + " " + population.getFittestTour().distance + " " + "fintness is:" + population.getFittestTour().fitness);
        while (true) {
            for (int i = filterSize; i < size - 1; i++) {
                Random random = new Random();
                int j = random.nextInt(filterSize - 1);
                int x = random.nextInt(filterSize - 1);
                while (j == x) {
                    x = random.nextInt(filterSize - 1);
                }
                Tour parent1 = population.tours.get(j);

                Tour parent2 = population.tours.get(x);

                Tour offspring1 = new Tour(parent1);
                Tour offspring2 = new Tour(parent2);
//                offspring1.cities.forEach(System.out::print);
//                System.out.println("-----"+i);
//                offspring2.cities.forEach(System.out::print);
//                System.out.println("-----"+i);
                if (random.nextInt(100) < crossoverRate * 100) {
                    crossover(offspring1, offspring2);
                }

                if (random.nextInt(100) < mutateRate * 100) {
                    mutation(offspring1);
                }
                population.tours.set(i, offspring1);
//                offspring1.cities.forEach(System.out::print);
//                System.out.println("-----"+i);
                if (random.nextInt(100) < mutateRate * 100) {
                    mutation(offspring2);
                }
                population.tours.set(i + 1, offspring2);
//                offspring2.cities.forEach(System.out::print);
//                System.out.println("-----"+i);

            }
            //population.tours.forEach(a -> System.out.println(a.fitness));
            generation++;
            population.selectPopulation();
            System.out.println("the generation:" + generation + " " + "distance:" + " " + population.getFittestTour().distance + " "
                    + "fintness is:" + population.getFittestTour().fitness + " " + "size:" + population.tours.get(0).cities.size());
            System.out.println("-------------------------------------------");
             lineChartData.setValue(population.getFittestTour().fitness , "Fitness", Integer.toString(generation));
            if (generation > 120) {  
              break;
            }
              
              
              chartPanel.setChart(chart);
              
              
//           
        }
    }

//    public void begin(int size, ArrayList<City> cityList) {
//		Population population = new Population();
//		int generation = 0;
//		for (int i = 0; i < size; i++) {
//			Tour tour = new Tour(cityList);
//			population.tours.add(tour);
//		}
//		//population.tours.forEach(a -> System.out.println(a.fitness));
//		population.getFittestTour();
//		System.out.println(
//				generation + " " + population.getFittestTour().distance + " " + population.getFittestTour().fitness);
//		while (true) {
//			for (int i = size / 2; i < size; i++) {
//				Tour mutatedTour;
//				Random random = new Random();
//				if (random.nextInt(10) >= 5) {
//					mutatedTour = mutation(population.tours.get(size - i - 1));
//				} else {
//					mutatedTour = population.tours.get(size - i - 1);
//				}
//				population.tours.set(i, mutatedTour);
//			}
//			//population.tours.forEach(a -> System.out.println(a.fitness));
//			generation++;
//			population.getFittestTour();
//			System.out.println(generation + " " + population.getFittestTour().distance + " "
//					+ population.getFittestTour().fitness + " " + population.tours.get(0).cities.size());
//			System.out.println("-------------------------------------------");
//			if (generation > 100) {
//				break;
//			}
//		}
//	}
    public ArrayList<City> getGeneCity(Tour t1, Tour t2) {
        ArrayList<City> cityList = new ArrayList<City>();
        for (int i = 1; i < t1.cities.size() - 1; i++) {
            City temp1 = t1.cities.get(i);
            if (!cityList.contains(temp1)) {
                cityList.add(temp1);
            }
        }
        for (int j = 1; j < t2.cities.size() - 1; j++) {
            City temp2 = t2.cities.get(j);
            if (!cityList.contains(temp2)) {
                cityList.add(temp2);
            }
        }
        return cityList;
    }

    public void crossover(Tour t1, Tour t2) {
        ArrayList<City> cityList = getGeneCity(t1, t2);
        Random random = new Random();
        Random r = new Random();
        int crossOverPoint = random.nextInt(12);
        while (crossOverPoint == 0) {
            crossOverPoint = random.nextInt(12);
        }

        int startpoint = r.nextInt(11) + 1;

        while (startpoint >= crossOverPoint) {
            startpoint = r.nextInt(12);
        }
//        System.out.println("startpoint" + startpoint + "" + "crossOverPoint" + "" + crossOverPoint);
        for (; startpoint < crossOverPoint; startpoint++) {
            City temp = t1.cities.get(startpoint);
            City temp2 = t2.cities.get(startpoint);
            t2.cities.set(startpoint, temp);
            t1.cities.set(startpoint, temp2);
        }
        delRepeat(t1, cityList);
        delRepeat(t2, cityList);

    }

    public boolean duplicate(City c, ArrayList<City> cityList) {
        int count = 0;
        for (int i = 0; i < cityList.size(); i++) {
            City temp = cityList.get(i);
            if (temp.equals(c)) {
                count++;
            }
        }
        return count > 0;
    }

    public void delRepeat(Tour t, ArrayList<City> cityList) {
        ArrayList<City> cities = new ArrayList<City>();
        Random random = new Random();
        for (int i = 0; i < t.cities.size(); i++) {
            City temp = t.cities.get(i);
            if (!cities.contains(temp)) {
                cities.add(temp);
            } else {
                int j = random.nextInt(cityList.size());

                City c = cityList.get(j);
                while (cities.contains(c)) {
                    j = random.nextInt(cityList.size());
                    c = cityList.get(j);
                }
                cities.add(c);
            }
        }
        t.setCities(cities);
    }

    public static Tour mutation(Tour tour) {
        Tour offSpring = new Tour(tour);
        int n = offSpring.cities.size();
        Random random = new Random();

        int c1 = random.nextInt(n - 1) + 1;
        int c2 = random.nextInt(n - 1) + 1;

        while (c1 == c2) {
            c2 = random.nextInt(n - 1) + 1;
        }

        City temp = offSpring.cities.get(c1);
        offSpring.cities.set(c1, offSpring.cities.get(c2));
        offSpring.cities.set(c2, temp);
        offSpring.fitness();
        return offSpring;
    }

}
